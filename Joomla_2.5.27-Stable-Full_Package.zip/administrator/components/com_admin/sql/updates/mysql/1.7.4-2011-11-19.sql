ALTER TABLE `#__languages` ADD UNIQUE `idx_image` (`image`);
ALTER TABLE `#__languages` ADD UNIQUE `idx_langcode` (`lang_code`);